import os
import json
import pandas as pd

folder_path = r"C:\Users\Jyothsna Prabhakar\Documents\mousedata"

all_data = []

for file in os.listdir(folder_path):
    if file.endswith(".json"):
        with open(os.path.join(folder_path, file), "r") as f:
            data = json.load(f)
            
            # Add file name for tracking
            for entry in data:
                entry['source_file'] = file
            
            all_data.extend(data)

df = pd.DataFrame(all_data)

print(df.head())