from sklearn.ensemble import IsolationForest
import pandas as pd

df = pd.read_csv("processed_data.csv")
# Use ONLY random data from Model 1
random_data = df[df['anomaly'] == -1].copy()

features = random_data[['speed', 'acceleration', 'angle', 'speed_var']]

model2 = IsolationForest(contamination=0.2, random_state=42)
model2.fit(features)

random_data = random_data.copy()
random_data.loc[:, 'quality'] = model2.predict(features)

# Keep ONLY high-quality randomness
high_quality = random_data[random_data['quality'] == -1]

print("High quality random samples:")
print(high_quality.head())

import hashlib

final_numbers = []

for i in high_quality.index:
    value = str(high_quality.loc[i, ['speed','acceleration','angle','speed_var']].values)
    hash_val = hashlib.sha256(value.encode()).hexdigest()
    final_numbers.append(hash_val)

print("\nFinal High-Quality Random Numbers:")
print(final_numbers[:5])