import os
import json
import pandas as pd
import numpy as np

folder_path = "C:\\Users\\Jyothsna Prabhakar\\OneDrive\\Desktop\\Documents\\Jyothsna Prabhakar\\ML ENTROPY PROJECT\\mousedata"

all_data = []

for file in os.listdir(folder_path):
    if file.endswith(".json"):
        with open(os.path.join(folder_path, file), "r") as f:
            data = json.load(f)
            
            # Add file name for tracking
            for entry in data:
                entry['source_file'] = file
            
            all_data.extend(data)

df = pd.DataFrame(all_data)

print(df.head())

# Remove rows with missing values
df = df.dropna()

# Convert types
df['x'] = df['x'].astype(float)
df['y'] = df['y'].astype(float)
df['time'] = df['time'].astype(float)

# Sort by time
df = df.sort_values(by='time')

# Reset index
df = df.reset_index(drop=True)

print(df.head())

# Calculate differences
df['dx'] = df['x'].diff()
df['dy'] = df['y'].diff()
df['dt'] = df['time'].diff()

# Speed
df['speed'] = ((df['dx']**2 + df['dy']**2)**0.5) / df['dt']

print(df.head())

# Remove invalid rows (dt = 0 or NaN)
df = df.dropna()
df = df[df['dt'] > 0]

# Acceleration
df['acceleration'] = df['speed'].diff()

# Direction (angle)
df['angle'] = np.arctan2(df['dy'], df['dx'])

# Variability (important for randomness)
df['speed_var'] = df['speed'].rolling(5).std()

# Drop new NaNs from rolling
df = df.dropna()

# Remove NaN values
df = df.dropna()

# Remove zero or negative time differences
df = df[df['dt'] > 0]

# Reset index
df = df.reset_index(drop=True)

print(df.head())
df = df.dropna()
df = df[df['dt'] > 0]
df = df.reset_index(drop=True)

from sklearn.ensemble import IsolationForest

# Select features for ML
features = df[['speed', 'acceleration', 'angle', 'speed_var']]

# Train model
model = IsolationForest(contamination=0.1, random_state=42)
model.fit(features)

# Predict
df['anomaly'] = model.predict(features)

print(df[['speed','acceleration','angle','speed_var','anomaly']].head())

import hashlib

random_numbers = []

# Take only random rows
random_rows = df[df['anomaly'] == -1]

for i in random_rows.index:
    # Combine feature values
    value = str(random_rows.loc[i, ['speed','acceleration','angle','speed_var']].values)
    
    # Convert to hash
    hash_val = hashlib.sha256(value.encode()).hexdigest()
    
    random_numbers.append(hash_val)

# Show output
print("Generated Random Numbers:")
print(random_numbers[:5])

df.to_csv("processed_data.csv", index=False)